# bloguvv.py
from app import app