namespace trabalho2
{
    public class BaconDecorator : HamburguerDecorator
    {
        public BaconDecorator(IHamburguer hamburguer) : base(hamburguer)
        {
        }

        public override string Descricao()
        {
            return base.Descricao() + " + Bacon";
        }

        public override double Custo()
        {
            return base.Custo() + 2.00;
        }
    }
}