using System;

namespace trabalho2
{
    public class MonitorMontagem : IObserver
    {
        public void Atualizar(Pedido pedido)
        {
            if (pedido.Estado == "Pronto para Montar")
            {
                //Console.Write("\nPedido pronto para montagem");
                
                Console.WriteLine("Pedido montado");
                pedido.Estado = "Pronto para Entrega";
                Console.Write("\nAperte qualquer tecla para continuar...");
                Console.ReadKey();
                
            }
        }

    }
}