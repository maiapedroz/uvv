namespace trabalho2
{
    public class HamburguerSimples : IHamburguer
    {
        public string Descricao()
        {
            return "Hamburguer Simples";
        }

        public double Custo()
        {
            return 8.00;
        }
    }
}