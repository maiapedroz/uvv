using System;
using System.Collections.Generic;

namespace trabalho2
{
    public class MonitorBalcao : IObserver
    {
        private List<Pedido> Pedidos;

        public MonitorBalcao(List<Pedido> pedidos)
        {
            Pedidos = pedidos;
        }
        
        
        public void Atualizar(Pedido pedido)
        { 
            
            if (Pedidos[0].Estado == "Pronto para Entrega")
            {
                //Console.Write("\nPedido pronto para retirada no balcão");
                
                Console.WriteLine("Pedido entregue");
                Pedidos.RemoveAt(Pedidos.IndexOf(pedido));
                Console.Write("\nAperte qualquer tecla para continuar...");
                Console.ReadKey();
                
            }
        }
    }
}