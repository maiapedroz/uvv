namespace trabalho2
{
    public class Acompanhamento
    {
        public string Nome { get; set; }
        public double Preco { get; set; }

        public Acompanhamento(string nome, double preco)
        {
            Nome = nome;
            Preco = preco;
        }
    }
}