namespace trabalho2
{
    public interface IHamburguer
    {
        string Descricao();
        double Custo();
    }
}