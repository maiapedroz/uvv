﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace trabalho2
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            List<Pedido> pedidos = new List<Pedido>();
            MonitorProducao producao = new MonitorProducao();
            MonitorMontagem montagem = new MonitorMontagem();
            MonitorBalcao balcao = new MonitorBalcao(pedidos);
            
            Acompanhamento c = new Acompanhamento("Coca-Cola", 6.00);
            Acompanhamento b = new Acompanhamento("Batata Frita", 10.00);
            Acompanhamento s = new Acompanhamento("Sobremesas", 10.00);
            
            int x = -1;
            while(x != 0)   // Controle do Menu
            {
                Console.Clear();
                Console.Write("\nMenu\n\n[1] Criar novo Pedido\n[2] Ver Pedidos\n[3] Processar Pedidos\n[0] Encerrar\n\nEscolha: ");
                x = int.Parse(Console.ReadLine());

                switch (x)
                {
                    case 0: // fechar programa 
                        break;
                    case 1: // Novo pedido
                        int y = -1;
                        IHamburguer hamburguerPedido = new HamburguerSimples();
                        List<Acompanhamento> listaAcompanhamentos = new List<Acompanhamento>();
                           
                        while (y != 0)      // Controle do Pedido
                        {
                            Console.Clear();

                            Console.WriteLine($"\nItens no pedido\nHamburguer: {hamburguerPedido.Descricao()}");
                            Console.Write("Acompanhamentos: ");
                            if (listaAcompanhamentos.Count > 0)
                            {
                                for (int i = 0; i < listaAcompanhamentos.Count; i++)
                                {   
                                    Console.Write(listaAcompanhamentos[i].Nome);
                                    if (i != listaAcompanhamentos.Count - 1)
                                    {
                                        Console.Write(" + ");
                                    }
                                }
                            }
                            else {
                                Console.Write("Nenhum");
                            }

                            
                            Console.Write(
                                $"\nPreço: {hamburguerPedido.Custo() + listaAcompanhamentos.Sum(acompanhamento => acompanhamento.Preco)}\n\n[1] Ver Adicionais\n[2] Acompanhamentos\n[3] Finalizar Pedido\n[0] Cancelar\n\nEscolha: ");
                            y = int.Parse(Console.ReadLine());
                            switch (y)
                            {
                                case 0:
                                    y = 0;
                                    break;
                                case 1:
                                    Console.Write(
                                        "Adicionar no Pedido:\n[1] Bacon\n[2] Queijo\n[3] Ovo\n[4] Alface\n[5] Tomate\n[0] Cancelar\n\nEscolha: ");

                                    int z = int.Parse(Console.ReadLine());

                                    switch (z)
                                    {
                                        case 0:
                                            break;
                                        case 1:
                                            hamburguerPedido = new BaconDecorator(hamburguerPedido);
                                            break;
                                        case 2:
                                            hamburguerPedido = new QueijoDecorator(hamburguerPedido);
                                            break;
                                        case 3:
                                            hamburguerPedido = new OvoDecorator(hamburguerPedido);
                                            break;
                                        case 4:
                                            hamburguerPedido = new AlfaceDecorator(hamburguerPedido);
                                            break;
                                        case 5:
                                            hamburguerPedido = new TomateDecorator(hamburguerPedido);
                                            break;
                                    }

                                    break;
                                case 2:
                                    Console.Write("Adicionar no Pedido:\n[1] Coca-Cola\n[2] Batata Frita\n[3] Sobremesas\n[0] Cancelar\n\nEscolha: ");
                                    int w = int.Parse(Console.ReadLine());
                                    switch (w)
                                    {
                                        case 0:
                                            break;
                                        case 1:
                                            listaAcompanhamentos.Add(c);
                                            break;
                                        case 2:
                                            listaAcompanhamentos.Add(b);
                                            break;
                                        case 3:
                                            listaAcompanhamentos.Add(s);
                                            break;
                                    }
                                    
                                    break;
                                case 3:
                                    y = 0;
                                    pedidos.Add(new Pedido(hamburguerPedido, listaAcompanhamentos));
                                    pedidos[pedidos.Count - 1].AddObserver(balcao);
                                    pedidos[pedidos.Count - 1].AddObserver(montagem);
                                    pedidos[pedidos.Count - 1].AddObserver(producao);
                                    
                                    Console.WriteLine("Pedido Efetuado");
                                    
                                    pedidos[pedidos.Count - 1].AvisarMonitores();
                                    //Console.ReadKey();
                                    //pedidos[pedidos.Count - 1].AvisarMonitores();
                                    break;
                                
                            }
                        }

                        break;
                    
                    case 2: // Ver Pedidos
                        int j = 1;
                        foreach (var variable in pedidos)   // Listar Pedidos
                        {
                            Console.Write($"Pedido {j}:\n");
                            Console.WriteLine("Hamburguer: " + variable.Hamburguer.Descricao());
                            Console.Write("Acompanhamentos: ");
                            if (variable.Acompanhamentos.Count > 0)
                            {
                                for (int i = 0; i < variable.Acompanhamentos.Count; i++)
                                {   
                                    Console.Write(variable.Acompanhamentos[i].Nome);
                                    if (i != variable.Acompanhamentos.Count - 1)
                                    {
                                        Console.Write(" + ");
                                    }
                                }

                            }
                            else {
                                Console.Write("Nenhum");
                            }
                            
                            Console.Write(
                                $"\nPreço: {variable.Hamburguer.Custo() + variable.Acompanhamentos.Sum(acompanhamento => acompanhamento.Preco)}\n");
                            Console.Write($"Estado: {variable.Estado}\n");
                            Console.Write("\n\n");
                            j++;
                        }   
                        Console.Write("[1] Cancelar pedido\n[2] Processar pedido\n[0] Retornar\n\nEscolha: ");
                        int v = int.Parse(Console.ReadLine());

                        switch (v)
                        {
                            case 0:
                                break;
                            case 1:
                                Console.Write("Qual pedido: ");
                                int q = int.Parse(Console.ReadLine());
                                
                                pedidos.RemoveAt(q - 1);
                                Console.Clear();
                                Console.Write($"Pedido {q} removido\nAperte qualquer tecla para continuar...");
                                Console.ReadKey();

                                break;
                            case 2:
                                Console.Write("Qual pedido: ");
                                int r = int.Parse(Console.ReadLine());
                                pedidos[r - 1].AvisarMonitores();
                                break;
                        }
                        break;
                    
                    case 3:
                        pedidos[0].AvisarMonitores();
                        break;
                }
            }
            
        }
    }
}