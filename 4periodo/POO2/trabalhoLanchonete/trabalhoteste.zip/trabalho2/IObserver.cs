using System.Collections.Generic;

namespace trabalho2
{
    public interface IObserver
    {
        void Atualizar(Pedido pedido);
    }
}