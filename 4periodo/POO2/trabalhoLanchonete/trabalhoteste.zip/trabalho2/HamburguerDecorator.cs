namespace trabalho2
{
    public abstract class HamburguerDecorator : IHamburguer
    {
        protected IHamburguer _hamburguer;

        public HamburguerDecorator(IHamburguer hamburguer)
        {
            _hamburguer = hamburguer;
        }

        public virtual string Descricao()
        {
            return _hamburguer.Descricao();
        }

        public virtual double Custo()
        {
            return _hamburguer.Custo();
        }
    }
}