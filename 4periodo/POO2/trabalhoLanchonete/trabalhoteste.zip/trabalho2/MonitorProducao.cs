using System;

namespace trabalho2
{
    public class MonitorProducao : IObserver
    {

        public void Atualizar(Pedido pedido)
        { 
            if (pedido.Estado == "Preparando")
            {
                //Console.Write("\nPedido pronto para ser feito");
                
                Console.WriteLine("Lanche preparado");
                pedido.Estado = "Pronto para Montar";
                Console.Write("\nAperte qualquer tecla para continuar...");
                Console.ReadKey();
                
            }
        }
    }
}