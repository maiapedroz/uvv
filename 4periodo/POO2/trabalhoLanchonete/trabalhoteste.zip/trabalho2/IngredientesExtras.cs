namespace trabalho2
// Decorator de ovo, alface, tomate
{
    public class BaconDecorator : HamburguerDecorator
    {
        public BaconDecorator(IHamburguer hamburguer) : base(hamburguer)
        {
        }

        public override string Descricao()
        {
            return base.Descricao() + " + Bacon";
        }

        public override double Custo()
        {
            return base.Custo() + 2.00;
        }
    }
    public class QueijoDecorator : HamburguerDecorator
    {
        public QueijoDecorator(IHamburguer hamburguer) : base(hamburguer) {}
        
        public override string Descricao()
        {
            return base.Descricao() + " + Queijo";
        }

        public override double Custo()
        {
            return base.Custo() + 1.00;
        }
    }
    public class OvoDecorator : HamburguerDecorator
    {
        public OvoDecorator(IHamburguer hamburguer) : base(hamburguer) {}

        public override string Descricao()
        {
            return base.Descricao() + " + Ovo";
        }

        public override double Custo()
        {
            return base.Custo() + 2.50;
        }
    }

    public class AlfaceDecorator : HamburguerDecorator
    {
        public AlfaceDecorator(IHamburguer hamburguer) : base(hamburguer) {}
        
        public override string Descricao()
        {
            return base.Descricao() + " + Alface";
        }

        public override double Custo()
        {
            return base.Custo() + 0.50;
        }
    }

    public class TomateDecorator : HamburguerDecorator
    {
        public TomateDecorator(IHamburguer hamburguer) : base(hamburguer) {}
        
        public override string Descricao()
        {
            return base.Descricao() + " + Tomate";
        }

        public override double Custo()
        {
            return base.Custo() + 1.00;
        }
    }
}